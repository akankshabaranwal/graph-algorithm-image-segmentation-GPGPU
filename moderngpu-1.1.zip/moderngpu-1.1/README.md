moderngpu
=========

Design patterns for GPU computing

Modern GPU is code and commentary intended to promote new and productive ways of thinking about GPU computing.

http://nvlabs.github.io/moderngpu
